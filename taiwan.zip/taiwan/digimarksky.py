from flask import Flask, render_template, request, redirect, url_for
import smtplib, ssl

app = Flask(__name__)

def send_email(sender, sender_email, message):
    # Email credentials
    email_address = 'info@schooltoppersaward.com'
    email_password = 'WhnfeW($}lO2'  

    # Recipient
    receiver = 'info@schooltoppersaward.com'

    # Connect to Namecheap SMTP server
    context = ssl.create_default_context()
    context.check_hostname = False
    context.verify_mode = ssl.CERT_NONE
    with smtplib.SMTP('smtp.schooltoppersaward.com', 587) as server:
        server.starttls(context=context)  # Pass the SSL context
        server.login(email_address, email_password)

        # Compose email
        email_message = f"From: {email_address}\nTo: {receiver}\nSubject: Contact Form Submission\n\n" \
                        f"Sender's Email: {sender_email}\n\n{message}"
        server.sendmail(email_address, receiver, email_message)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/send_email', methods=['POST'])
def send_email_route():
    if request.method == 'POST':
        fname = request.form['F_name']
        lname = request.form['L_name']
        mobile = request.form['mobile']
        email = request.form['email']
        message = request.form['message']
        sender = f"{fname} {lname}"

        # Combine the message parts
        full_message = f"First Name: {fname}\nLast Name: {lname}\nContact No.: {mobile}\nEmail: {email}\nMessage: {message}"

        # Send the email
        send_email(sender, email, full_message)

        return redirect(url_for('thank_you'))

@app.route('/thankyou')
def thank_you():
    return "Thank you for your message. It has been sent."

if __name__ == '__main__':
    app.run(debug=True)
